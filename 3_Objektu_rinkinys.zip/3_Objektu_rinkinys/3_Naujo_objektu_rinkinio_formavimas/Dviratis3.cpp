#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;
//----------------------------------------------------
const int Cn = 100;
const char Fd1[] = "Nuoma1.txt"; // pirmo nuomos punkto dviraciu sarasas
const char Fd2[] = "Nuoma2.txt"; // antro nuomos punkto dviraciu sarasas
const char Frez[] = "NuomaRez.txt";
//----------------------------------------------------
class Dviratis
{
private:
  string pav;
  int kiek;
  int metai;     // pagaminimo metai
  double kaina;
public:
  void Deti(string pav, int kiek, int metai, double kaina);
  string ImtiPav() { return pav;}
  int ImtiKiek() { return kiek; }
  int ImtiMetus() { return metai;  }
  double ImtiKaina() { return kaina; }
  void PapildytiKiek(int k) { kiek += k;}
};
//----------------------------------------------------
void Skaityti(const char Fd[], Dviratis d[], int & n, string & pav);
int Seniausias(Dviratis d[], int n);
int YraModelis(Dviratis d[], int n, string pav);
void Formuoti(Dviratis d[], int n, Dviratis dr[], int & nr);
void Spausdinti(ofstream & F, Dviratis d[], int n, string pav);
//----------------------------------------------------
int main()
{
     // Pirmojo dviraciu nuomos punktui
  Dviratis d1[Cn];  // dviraciu duomenys
  int n1;           // dviraciu skaicius
  string pav1;      // nuomos punkto pavadinimas
     // Antrojo dviraciu nuomos punktui
  Dviratis d2[Cn]; // dviraciu duomenys
  int n2;          // dviraciu skaicius
  string pav2;     // nuomos punkto pavadinimas

  ofstream fr (Frez);
  Skaityti(Fd1, d1, n1, pav1);
  Spausdinti(fr, d1, n1, pav1);
  Skaityti(Fd2, d2, n2, pav2);
  Spausdinti(fr, d2, n2, pav2);
  if(d1[Seniausias(d1, n1)].ImtiMetus() < d2[Seniausias(d2, n2)].ImtiMetus())
       cout << "Seniausias dviratis yra nuomos punkte " << pav1 << endl;
  else cout << "Seniausias dviratis yra nuomos punkte " << pav2 << endl;
  Dviratis dr[Cn]; int nr;
  nr = 0;
  Formuoti(d1, n1, dr, nr);
  Formuoti(d2, n2, dr, nr);
  Spausdinti(fr, dr, nr, "Modeliu sarasas");
  fr.close();
  return 0;
}
//---------------------------------------------------
void Dviratis::Deti(string pav, int kiek, int metai, double kaina)
{
   this->pav = pav;
   this->kiek = kiek;
   this->metai = metai;
   this->kaina = kaina;
}
//---------------------------------------------------
void Skaityti(const char Fd[], Dviratis d[], int & n, string & pav)
{
    string eil; int kiek; int metai; double kaina;
    ifstream F(Fd);
    getline(F, pav);
    F >> n;
    for(int i = 0; i < n; i++){
      F >> eil >> kiek >> metai >> kaina;
      d[i].Deti(eil, kiek, metai, kaina);
      F.ignore(80, '\n');
    }
    F.close();
}
//---------------------------------------------------
void Spausdinti(ofstream & F, Dviratis d[], int n, string pav)
{
  F << pav << endl;
  F << "-------------------------------------\n";
  F << " Modelis      Kiekis   Data   Kaina \n";
  F << "-------------------------------------\n";
  for( int i = 0; i < n; i++)
    F << setw(15) << left  << d[i].ImtiPav()
      << setw(4)  << right << d[i].ImtiKiek()
      << setw(8)  << d[i].ImtiMetus()
      << setw(10) << right << d[i].ImtiKaina() << endl;
  F << "-------------------------------------\n";
  F << endl;
}
//----------------------------------------------------
int Seniausias(Dviratis d[], int n)
{
  int k = 0;
  for(int i = 0; i < n; i++)
    if(d[i].ImtiMetus() < d[k].ImtiMetus())
      k = i;
  return k;
}
//---------------------------------------------------
int YraModelis(Dviratis d[], int n, string pav)
{
  for( int i = 0; i < n; i++)
    if(d[i].ImtiPav() == pav) return i;
  return -1;
}
//---------------------------------------------------
void Formuoti(Dviratis d[], int n, Dviratis dr[], int & nr)
{
 int k;
 for(int i = 0; i < n; i++ ) {
  k = YraModelis(dr, nr, d[i].ImtiPav());
  if(k >= 0)
     dr[k].PapildytiKiek(d[i].ImtiKiek());
  else  {dr[nr] = d[i]; nr++;}
 }
}
//---------------------------------------------------

