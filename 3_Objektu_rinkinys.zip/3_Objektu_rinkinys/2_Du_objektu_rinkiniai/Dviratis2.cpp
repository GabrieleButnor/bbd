#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;
//----------------------------------------------------
const int Cn = 100;
const char Fd1[] = "Duom1.txt";
const char Fd2[] = "Duom2.txt";
//----------------------------------------------------
class Dviratis
{
private:
  int metai;     // pagaminimo metai
  double kaina;
public:
  void Deti(int metai, double kaina);
  int ImtiMetus() { return metai;  }
  double ImtiKaina() { return kaina; }
};
//----------------------------------------------------
void Dviratis::Deti(int metai, double kaina)
{
   this->metai = metai;
   this->kaina = kaina;
}
//---------------------------------------------------
void Skaityti(const char Fd[], Dviratis D[], int & n, int & am, string & pav);
void Pinigai( Dviratis D[], int n, int amPr, int amPb, int & kiek, double & suma);
double Vidurkis(Dviratis D[], int n, int amPr, int amPb);
//----------------------------------------------------
int main()
{
        // Pirmas dviraciu nuomos punktas
  Dviratis D1[Cn];  // dviraciu duomenys
  int n1;           // dviraciu skaicius
  int am1;          // dviracio tinkamumo naudoti kritinis amzius
  string pav1;      // nuomos punkto pavadinimas
  int kiekTinka1, kiekNetinka1;
  double sumaTinka1, sumaNetinka1;

  Skaityti(Fd1, D1, n1, am1, pav1);
  Pinigai(D1, n1, 0, am1, kiekTinka1, sumaTinka1);
  cout << "Pirmas dviraciu punktas \n";
  cout << "Tinkami naudoti: " << kiekTinka1 << " "
       <<  sumaTinka1 << endl;
  Pinigai(D1, n1, am1 + 1, 1000, kiekNetinka1, sumaNetinka1);
  cout << "Netinkami naudoti: " << kiekNetinka1 << " "
       <<  sumaNetinka1 << endl;
  cout << "Tinkamu naudoti dviraciu vidutinis amzius: " << Vidurkis(D1, n1, 0, am1) << endl;
  cout << "Netinkamu naudoti dviraciu vidutinis amzius: " << Vidurkis(D1, n1, am1 + 1, 1000) << endl;
  cout << endl;

       // Antras dviraciu nuomos punktas
  Dviratis D2[Cn]; // dviraciu duomenys
  int n2;          // dviraciu skaicius
  int am2;         // dviracio tinkamumo naudoti kritinis amzius
  string pav2;     // nuomos punkto pavadinimas
  int kiekTinka2, kiekNetinka2;
  double sumaTinka2, sumaNetinka2;

  Skaityti(Fd2, D2, n2, am2, pav2);
  Pinigai(D2, n2, 0, am2, kiekTinka2, sumaTinka2);
  cout << "Antras dviraciu punktas \n";
  cout << "Tinkami naudoti: " << kiekTinka1 << " "
       <<  sumaTinka2 << endl;
  Pinigai(D2, n2, am2 + 1, 1000, kiekNetinka2, sumaNetinka2);
  cout << "Netinkami naudoti: " << kiekNetinka2 << " "
       <<  sumaNetinka2 << endl;
  cout << "Tinkamu naudoti dviraciu vidutinis amzius: " << Vidurkis(D2, n2, 0, am2) << endl;
  cout << "Netinkamu naudoti dviraciu vidutinis amzius: " << Vidurkis(D2, n2, am2 + 1, 1000) << endl;
  return 0;
}
//---------------------------------------------------
void Skaityti(const char Fd[], Dviratis D[], int & n, int & am, string & pav)
{
    int metai; double kaina;
    ifstream F(Fd);
    getline(F, pav);
    F >> am >> n;
    for(int i = 0; i < n; i++){
      F >> metai >> kaina;
      D[i].Deti(metai, kaina);
    }
    F.close();
}
//---------------------------------------------------
void Pinigai( Dviratis D[], int n, int amPr, int amPb, int & kiek, double & suma)
{
    kiek = 0;
    suma = 0.0;
    int amzius;
    for(int i = 0; i < n; i++){
      amzius = 2012 - D[i].ImtiMetus();
      if((amPr <= amzius) && (amzius <= amPb))
      {
        kiek++; suma += D[i].ImtiKaina();
      }
    }
}
//---------------------------------------------------
double Vidurkis(Dviratis D[], int n, int amPr, int amPb)
{
  int kiek = 0, suma = 0;
  int amzius;
  for(int i = 0; i < n; i++){
     amzius = 2012 - D[i].ImtiMetus();
     if((amPr <= amzius) && (amzius <= amPb))
     {
        kiek++; suma += amzius;
     }
  }
  if(kiek > 0) return (double) suma / kiek;
  else return 0.0;
}
//---------------------------------------------------

