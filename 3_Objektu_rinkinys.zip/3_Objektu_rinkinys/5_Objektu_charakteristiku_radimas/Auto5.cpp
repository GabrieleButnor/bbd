#include <iostream>   
#include <fstream>   
using namespace std;  
#include <iomanip>    
#include <string>

class Auto
{
private:
  string pav;            // automobilio pavadinimas
  string degalai;        // degal� tipas
  double s�naudos;       // kuro s�naudos 100 km
public:
  void D�ti(string p, string d, double s);
  string ImtiPav()      { return pav;      }
  string ImtiDegalus()  { return degalai;  }
  double ImtiS�naudas() { return s�naudos; }
};
//----------------------------------------------------
void Auto::D�ti(string p, string d, double s)
{
    pav = p;       // automobilio pavadinimas
    degalai = d;   // automobilio pavadinimas
    s�naudos = s;  // kuro s�naudos 100 km
}
//----------------------------------------------------
void �vestiDuomenis(string fv, Auto A[], int &kiek);
void SpausdintiDuomenis(string fv, Auto A[], int kiek);
double VidS�naudos(Auto A[], int kiek);
//----------------------------------------------------
int main()
{
	setlocale(LC_ALL, "Lithuanian");
	ofstream fr("Rezultatai.txt"); fr.close();
	Auto A[100];             // automobili� duomenys
	int na;                  // automobili� kiekis
	�vestiDuomenis("Duomenys.txt", A, na);
	SpausdintiDuomenis("Rezultatai.txt", A, na);
	fr.open("Rezultatai.txt", ios::app);
	fr.setf(ios::fixed); fr.setf(ios::left);
	fr << "Vidutin�s degal� s�naudos: " << setprecision(2) << VidS�naudos(A, na) << " litro/100 km" << endl;
	fr.close();
	cout << "Programa baig� darb�\n";
	return 0;
}
//----------------------------------------------------
// I� failo fv �veda duomenis � objekt� masyv� A(kiek).
void �vestiDuomenis(string fv, Auto A[], int &kiek)
{
	string pav, degalai;        
	double s�naudos;  
	ifstream fd(fv.c_str());
	fd >> kiek; fd.ignore();
	for (int i=0; i<kiek; i++) {
		getline(fd, pav, ','); fd >> ws;
		getline(fd, degalai, ',');
		fd >> s�naudos;
		A[i].D�tiPav(pav);
		A[i].D�tiDegalus(degalai);
		A[i].D�tiS�naudas(s�naudos);
		fd.ignore();
	}
	fd.close();
}
//------------------------------------------------------------
// Objekt� masyvo A(kiek) reik�mes spausdina lentele � fail� fv
void SpausdintiDuomenis(string fv, Auto A[], int kiek)
{
	ofstream fr(fv.c_str(), ios::app);
	fr.setf(ios::fixed); fr.setf(ios::left);
	fr << "Automobili� skai�ius: " << kiek << endl;
	fr << "Automobili� s�ra�as:\n";
	fr << "----------------------------------------------------\n";
	fr << "|   Pavadinimas   |  Degalai   | S�naudos (l/100 km)\n";
	fr << "----------------------------------------------------\n";
	for (int i=0; i<kiek; i++) {
		fr << "| " << setw(15) << A[i].ImtiPav() << " | " << setw(10) << A[i].ImtiDegalus() 
			<< " |        " << setprecision(2) << A[i].ImtiS�naudas() << "       | " << endl;
	}
	fr << "----------------------------------------------------\n";
	fr.close();
}
//----------------------------------------------------
// Skai�iuoja ir gr��ina objekt� masyvo A(kiek) lauko s�naudos vidutin� reik�m�
double VidS�naudos(Auto A[], int kiek)
{
	double sum = 0;
	for (int i=0; i<kiek; i++) {
		sum = sum + A[i].ImtiS�naudas();
	}
	return sum / kiek;
}
//----------------------------------------------------

